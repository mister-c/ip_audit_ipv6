#ifndef _STR_UTIL_H
#define _STR_UTIL_H

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

char *Strdup(const char *str);
char *Strconcat(const char *s1, const char *s2);
int chomp(char *line);
#endif /* _STR_UTIL_H */
