#ifndef __IPAUDITS_H
#define __IPAUDITS_H

/* needed for strptime - _XOPEN_SOURCE was supposed to work.*/
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif /* !_GNU_SOURCE */

#define BUFSIZE 262144

#include <time.h>
#include "str_util.h"

/** note:
    lists are on the todo list
*/

typedef struct _progvars
{
    int pretty_print;
    int showlinecount;
    int debug_pv;
    int normal;
    time_t now;
    char *orig_dir;
    char *ipaudit_30min;
    Search search;
} PV;

#endif /* __IPAUDITS_H */
